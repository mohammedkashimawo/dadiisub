<footer class="main-footer text-center">
    <i>&copy; <?php echo date("Y"); ?> . <a href="https://aduikirun.com.ng/">Licensed By ADU All Rights Reserved.</a></i>
</footer>