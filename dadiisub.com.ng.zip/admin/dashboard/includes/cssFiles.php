    <!-- Bootstrap 4.0-->
    <link rel="stylesheet" type="text/css" href="<?php echo $assetsLoc; ?>/vendor_components/bootstrap/dist/css/bootstrap.css">
        
	<!-- Bootstrap extend-->
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsLoc; ?>/css/bootstrap-extend.css">

    <!-- Data Table-->
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsLoc; ?>/vendor_components/datatable/datatables.min.css"/>
	
	<!-- Sweetalert Table-->
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsLoc; ?>/vendor_components/sweetalert/sweetalert.css"/>
	
	<!-- include summernote css/js -->
	<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
	<!-- theme style -->
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsLoc; ?>/css/master_style.css">
	
	<!-- Azurex Admin skins -->
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsLoc; ?>/css/skins/_all-skins.css">	

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

	<style>
	#editor {min-height: 200px;}
	.sale-icon{border:3px solid #f2f2f2; width:80px; height:80px; margin-bottom:10px; border-radius:35rem;}
	</style>