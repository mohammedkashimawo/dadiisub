<?php 

    /*
     
      
        Website: www.topupmate.com
        
        PWhatsapp: 07032529431
    */

    
    $design = $data3->homedesign;
    $color = $data3->sitecolor;
    $name = $data3->sitename;

    include("homepages/homepage".$design.".php");

?>