<?php 

    /*
        
    */

    header("Location:login/");

?>